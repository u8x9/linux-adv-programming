#!/bin/bash
# #!用于指定当前脚本文件的shell解释器的类型，如果不写，则用默认的shell


#shell脚本是shell命令的有序集合，代码的构成就是命令

ls

pwd

echo "hello world"
