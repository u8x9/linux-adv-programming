#!/bin/bash

echo "You are welcome to use bash"
echo "Current work dirctory is $PWD"
echo "the host name is  $HOSTNAME"
echo "your home dir  $HOME"
echo "Your shell is  $SHELL"
echo "user env val is $MYVAL1"