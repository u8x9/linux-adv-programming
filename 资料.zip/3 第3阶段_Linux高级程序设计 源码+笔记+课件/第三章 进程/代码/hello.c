#include <stdio.h>

int main(int argc, const char *argv[])
{
	printf("***************************\n");
	printf("正在执行hello.c的可执行文件\n");
	printf("---------------------------\n");
	
	return 0;
}
