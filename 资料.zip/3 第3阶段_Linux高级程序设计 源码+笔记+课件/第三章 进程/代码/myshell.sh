#!/bin/bash

echo "hahahahahahahahaha"
echo "正在执行myshell.sh"
echo "heiheiheiheiheihei"
